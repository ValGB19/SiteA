package javas.Interfaces;

/**
 * Title:       Planta<p>
 * Description: Interface que define una estructura para representar 
 * para representar a los Plantas.
 * Facilita el filtrado con el instanceof.
 * <p>
 * Copyright:   None <p>
 * Company:     None<p>
 * @author Grupo:  Dalessandro Garcia, Saenz.
 * @version 0.1
 */

public interface Planta extends Personage{
	
}
